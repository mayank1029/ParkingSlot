package com.parkingslot.main;

import com.parkingslot.actions.Actions;

public class ActionsManager {
	
	private Actions action;
	
	public ActionsManager() {
	}
	
	public void setAction(Actions action) {
		this.action = action;
	}

	public String executeActions() {
		return action.process();
	}

}
