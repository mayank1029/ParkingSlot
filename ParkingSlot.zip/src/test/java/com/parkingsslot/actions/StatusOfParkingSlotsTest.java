package com.parkingsslot.actions;

import static org.junit.Assert.*;

import org.junit.Test;

public class StatusOfParkingSlotsTest {

	@Test
	public void testProcess() {
		fail("Not yet implemented");
	}

}
