package com.parkingsslot.actions;

import static org.junit.Assert.*;

import org.junit.Test;

public class FilterRegNumsBasedOnColorTest {

	@Test
	public void testProcess() {
		fail("Not yet implemented");
	}

}
