package com.parkingsslot.actions;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.parkingslot.actions.CreatParkingLot;

public class CreatParkingLotTest {

	private CreatParkingLot classUnderTest;
	private String inputString = "create_parking_lot 6";

	@Before
	public void init() {
		String[] input = inputString.split(" ");
		classUnderTest = new CreatParkingLot(input);
	}

	@Test
	public void testProcess() {
		assertEquals("Created a parking lot with 6 slots", classUnderTest.process());
	}

}
