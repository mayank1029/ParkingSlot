package com.parkingsslot.actions;

import static org.junit.Assert.fail;

import org.junit.Test;

public class AlotParkingSlotTest {
	

	@Test
	public void testAlotParkingSlot() {
		fail("Not yet implemented");
	}

	@Test
	public void testProcess() {
		fail("Not yet implemented");
	}

}
