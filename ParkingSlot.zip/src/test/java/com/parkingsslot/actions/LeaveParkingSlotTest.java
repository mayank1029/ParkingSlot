package com.parkingsslot.actions;

import static org.junit.Assert.*;

import org.junit.Test;

public class LeaveParkingSlotTest {

	@Test
	public void testProcess() {
		fail("Not yet implemented");
	}

}
