package com.parkingsslot.actions;

import static org.junit.Assert.*;

import org.junit.Test;

public class FilterSlotNumBasedOnRegNumTest {

	@Test
	public void testProcess() {
		fail("Not yet implemented");
	}

}
