package com.parkingslot.main;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ParkingSlotApplicationTest {

	public ParkingSlotApplication classUndertest;
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

	@Before
	public void setUpStreams() {
		System.setOut(new PrintStream(outContent));
		classUndertest = new ParkingSlotApplication();
	}

	@After
	public void cleanUpStreams() {
		System.setOut(null);
	}

	@Test
	public void testMain() throws IOException {

		File f = new File("/Users/Minku/SearchWorkspace/ParkingSlot/src/test/resources/input-file.txt");
		classUndertest.startProcessing(f);
		String[] result = outContent.toString().split("\n");

		assertEquals("Created a parking lot with 6 slots", result[0]);
		assertEquals("Allocated slot number: 1", result[1]);

	}

}
