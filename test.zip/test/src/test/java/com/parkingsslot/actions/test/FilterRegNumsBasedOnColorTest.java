package com.parkingsslot.actions.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.parkingslot.actions.FilterRegNumsBasedOnColor;

public class FilterRegNumsBasedOnColorTest {

	private String[] input;
	private FilterRegNumsBasedOnColor test;

	@Before
	public void init() {

		input= new String[2];
		input[0]="registration_numbers_for_cars_with_colour";
		input[1]="White";
	}

	@Test
	public void testProcess() {
		test = new FilterRegNumsBasedOnColor(input);
		assertNotNull(input);
		assertEquals(input.length, 2);
	}

}
