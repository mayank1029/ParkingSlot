package com.parkingsslot.actions.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.parkingslot.actions.FilterSlotNumsBasedOnColor;

public class FilterSlotNumsBasedOnColorTest {

	private String[] input;
	private FilterSlotNumsBasedOnColor test;

	@Before
	public void init() {

		input= new String[2];
		input[0]="slot_numbers_for_cars_with_colour";
		input[1]="White";
	}

	@Test
	public void testProcess() {
		test = new FilterSlotNumsBasedOnColor(input);
		assertNotNull(input);
		assertEquals(input.length, 2);
	}

}
