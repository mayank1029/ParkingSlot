package com.parkingsslot.actions;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CreatParkingLotTest {
	
	private int totalParkinglot;
	
	@Before
	public void init() {
		totalParkinglot=3;
	}

	@Test
	public void testProcess() {
		assertNotNull(totalParkinglot);
		assertTrue(totalParkinglot>0);
		fail("Not yet implemented");
	}

}
