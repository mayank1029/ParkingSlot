package com.parkingsslot.actions.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.parkingslot.actions.CreatParkingLot;




public class CreatParkingLotTest {
	
	private int totalParkinglot;
	private CreatParkingLot test;
	private String[] input;
	
	@Before
	public void init() {
		totalParkinglot=3;
		 input= new String[2];
		 input[0]="create_parking_lot";
		 input[1]="3";
	}

	@Test
	public void testProcess() {
		
		test=new CreatParkingLot(input);
		
		String output=test.process();
		assertNotNull(output);
		assertEquals("Created a parking lot with "+totalParkinglot+" slots", output);
		assertNotNull(totalParkinglot);
		assertTrue(totalParkinglot>0);
		assertEquals(input.length, 2);
	}

}
