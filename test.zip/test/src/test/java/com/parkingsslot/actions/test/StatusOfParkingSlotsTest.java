package com.parkingsslot.actions.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.parkingslot.actions.StatusOfParkingSlots;

public class StatusOfParkingSlotsTest {

	private String[] input;
	private StatusOfParkingSlots test;

	@Before
	public void init() {

		input= new String[1];
		input[0]="status";
	}

	@Test
	public void testProcess() {
		test = new StatusOfParkingSlots(input);
		assertNotNull(input);
		assertEquals(input.length, 1);
	}

}
