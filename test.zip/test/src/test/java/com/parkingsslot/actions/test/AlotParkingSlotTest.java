package com.parkingsslot.actions.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.parkingslot.actions.AlotParkingSlot;
import com.parkingslot.main.ParkingSlotApplication;
import com.parkingslot.model.Slot;
import com.parkingslot.model.Ticket;

public class AlotParkingSlotTest {
	
	private String regNum;
	private String color;
	private List<Slot> listOfSlots; 
	private Ticket ticket;
	private String[] input;
	private AlotParkingSlot test;



	@Before
	public void init() {
		
		 input= new String[3];
		 input[0]="park";
		 input[1]="KA-01-HH-1234";
		 input[2]="White";
		 regNum=input[1];
		 color=input[2];
		 listOfSlots=ParkingSlotApplication.getListOfSlots();
	}

	@Test
	public void testProcess() {
		test=new AlotParkingSlot(input);
		assertNotNull(regNum);
		assertNotNull(color);
		assertEquals(input.length, 3);

//		assertNotNull(listOfSlots);
	}

}
