package com.parkingsslot.actions.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.parkingslot.actions.FilterSlotNumBasedOnRegNum;

public class FilterSlotNumBasedOnRegNumTest {

	private String[] input;
	private FilterSlotNumBasedOnRegNum test;

	@Before
	public void init() {

		input= new String[2];
		input[0]="slot_number_for_registration_number";
		input[1]="KA-01-HH-3141";
	}

	@Test
	public void testProcess() {
		test = new FilterSlotNumBasedOnRegNum(input);
		assertNotNull(input);
		assertEquals(input.length, 2);
	}

}
