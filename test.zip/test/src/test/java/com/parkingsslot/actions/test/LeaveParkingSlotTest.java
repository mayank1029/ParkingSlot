package com.parkingsslot.actions.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.parkingslot.actions.LeaveParkingSlot;

public class LeaveParkingSlotTest {

	private String[] input;
	private LeaveParkingSlot test;

	@Before
	public void init() {

		input= new String[2];
		input[0]="leave";
		input[1]="4";
	}

	@Test
	public void testProcess() {
		test = new LeaveParkingSlot(input);
		assertNotNull(input);
		assertEquals(input.length, 2);
	}

}
