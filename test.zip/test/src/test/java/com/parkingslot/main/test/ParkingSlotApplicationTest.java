package com.parkingslot.main.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class ParkingSlotApplicationTest {

	@Test
	public void testMain() {
	}

}
