package com.parkingslot.main;

import static org.junit.Assert.*;

import org.junit.Test;

public class ParkingSlotApplicationTest {

	@Test
	public void testMain() {
		fail("Not yet implemented");
	}

}
