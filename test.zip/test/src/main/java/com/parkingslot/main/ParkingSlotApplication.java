package com.parkingslot.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.parkingslot.actions.AlotParkingSlot;
import com.parkingslot.actions.CreatParkingLot;
import com.parkingslot.actions.FilterRegNumsBasedOnColor;
import com.parkingslot.actions.FilterSlotNumBasedOnRegNum;
import com.parkingslot.actions.FilterSlotNumsBasedOnColor;
import com.parkingslot.actions.LeaveParkingSlot;
import com.parkingslot.actions.Actions;
import com.parkingslot.actions.StatusOfParkingSlots;
import com.parkingslot.model.Slot;
import com.parkingslot.model.Ticket;

public class ParkingSlotApplication {

	public static List<Slot> listOfSlots;
	private static Map<Integer,Ticket> issueTicket = new LinkedHashMap<>();

	public static Map<Integer, Ticket> getIssueTicket() {
		return issueTicket;
	}

	public static List<Slot> getListOfSlots() {
		return listOfSlots;
	}

	public static void main(String[] args) {
		File f=new File(args[0]);
		BufferedReader br=null;

		try {
			br=new BufferedReader(new FileReader(f));
			String command=null;
			String[] inputArray=null;
			ActionsManager am=new ActionsManager();


			Map<String,Class<? extends Actions>> actionsMap=new HashMap<>();
			actionsMap.put("create_parking_lot",CreatParkingLot.class);
			actionsMap.put("park",AlotParkingSlot.class);
			actionsMap.put("leave",LeaveParkingSlot.class);
			actionsMap.put("status",StatusOfParkingSlots.class);
			actionsMap.put("registration_numbers_for_cars_with_colour",FilterRegNumsBasedOnColor.class);
			actionsMap.put("slot_numbers_for_cars_with_colour",FilterSlotNumsBasedOnColor.class);
			actionsMap.put("slot_number_for_registration_number", FilterSlotNumBasedOnRegNum.class);

			while((command=br.readLine())!=null) {
				inputArray=command.split(" ");

				Actions pa=(Actions) actionsMap.get(inputArray[0]).getDeclaredConstructors()[0].newInstance(new Object[] {inputArray});
				am.setAction(pa);
				System.out.println(am.executeActions());
			}

			br.close();

		} catch (IOException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | SecurityException | NullPointerException e) {
			if(e instanceof NullPointerException) {
				if(ParkingSlotApplication.listOfSlots == null || !(ParkingSlotApplication.listOfSlots.size()>0)) {
					System.out.println("ERROR! No parking created.First create the parking slots.");
				}
			}else {
				e.printStackTrace();
			}
		}finally {
			if(br!=null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
