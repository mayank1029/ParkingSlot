package com.parkingslot.actions;

import com.parkingslot.main.ParkingSlotApplication;

public class LeaveParkingSlot implements Actions {

	private int parkingSlotNumber;

	public LeaveParkingSlot(String[] input) {
		this.parkingSlotNumber=Integer.parseInt(input[1]);
	}

	@Override
	public String process() throws NullPointerException{
		
		ParkingSlotApplication.getIssueTicket().get(parkingSlotNumber).getSlot().unPark();
		ParkingSlotApplication.getIssueTicket().remove(parkingSlotNumber);
		return "Slot number "+this.parkingSlotNumber+" is free";
	}
	
	
}
