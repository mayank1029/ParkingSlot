package com.parkingslot.actions;

import java.util.ArrayList;
import java.util.List;

import com.parkingslot.main.ParkingSlotApplication;
import com.parkingslot.model.Slot;

public class CreatParkingLot implements Actions {
	
	private int totalParkingLot;
	
	public CreatParkingLot(String[] input) {
		this.totalParkingLot=Integer.parseInt(input[1]);
	}

	@Override
	public String process() throws NullPointerException{
		List<Slot> listOfSlots=new ArrayList<Slot>();
		for(int i=1;i<=totalParkingLot;i++) {
			listOfSlots.add(new Slot(i));
			}
		ParkingSlotApplication.listOfSlots=listOfSlots;
		return "Created a parking lot with "+totalParkingLot+" slots";
	}

}
