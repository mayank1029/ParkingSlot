package com.parkingslot.actions;

import java.util.Map;

import com.parkingslot.model.Ticket;

public interface ProcessAction {

	public String process() ;
}
