package com.parkingslot.actions;

import java.util.Map;
import java.util.stream.Collectors;

import com.parkingslot.main.ParkingSlotApplication;
import com.parkingslot.model.Ticket;

public class FilterSlotNumsBasedOnColor implements Actions {
	
	private String inputVal;
	private Map<Integer,Ticket> issueTicket;
	
	public FilterSlotNumsBasedOnColor(String[] input) {
		this.inputVal=input[1];
		this.issueTicket=ParkingSlotApplication.getIssueTicket();
	}

	@Override
	public String process() throws NullPointerException{
		String output=issueTicket.entrySet().stream().
				filter(x->inputVal.equals(x.getValue().getCar().getColour())).
				map(x->String.valueOf(x.getValue().getParkingSlotNumber())).collect(Collectors.joining(", "));

		return output;
	}

}
