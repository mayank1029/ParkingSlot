package com.parkingslot.actions;

import java.util.Iterator;
import java.util.List;

import com.parkingslot.main.ParkingSlotApplication;
import com.parkingslot.model.Car;
import com.parkingslot.model.Slot;
import com.parkingslot.model.Ticket;

public class AlotParkingSlot implements Actions {

	private String regNum;
	private String color;
	private List<Slot> listOfSlots; 
	private Ticket ticket;

	public AlotParkingSlot(String[] input) {
		this.regNum=input[1];
		this.color=input[2];
		this.listOfSlots=ParkingSlotApplication.getListOfSlots();
	}

	@Override
	public String process() throws NullPointerException{
		String output=null;
		Slot slot=getFirstEmptySlot();
		if(slot==null) {
			output="Sorry, parking lot is full";
		}else {
			slot.park();
			Ticket ticket=new Ticket(new Car(color,regNum),slot.getSlotNumber(),slot);
			this.ticket=ticket;
			output="Allocated slot number: "+slot.getSlotNumber();
			ParkingSlotApplication.getIssueTicket().put(slot.getSlotNumber(), ticket);
		}
		return output;
	}

	private Slot getFirstEmptySlot() throws NullPointerException{
		boolean isSlotFound = false;
		Slot emptySlot=null;
		Iterator<Slot> iterator=listOfSlots.iterator();

		while(iterator.hasNext() && !isSlotFound) {
			emptySlot=iterator.next();
			if(!emptySlot.isOccupied()) {
				isSlotFound=true;
			}
		}
		if(!isSlotFound) {
			return null;
		}

		return emptySlot;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}



}
