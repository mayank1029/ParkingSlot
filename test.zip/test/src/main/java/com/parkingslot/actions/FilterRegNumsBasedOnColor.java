package com.parkingslot.actions;

import java.util.Map;
import java.util.stream.Collectors;

import com.parkingslot.main.ParkingSlotApplication;
import com.parkingslot.model.Ticket;

public class FilterRegNumsBasedOnColor implements Actions {
	
	private String inputVal;
	private Map<Integer,Ticket> issueTicket;

	public FilterRegNumsBasedOnColor(String[] input) {
		this.inputVal=input[1];
		this.issueTicket=ParkingSlotApplication.getIssueTicket();
	}

	@Override
	public String process() throws NullPointerException{
		String output=issueTicket.entrySet().stream().
				filter(x->inputVal.equals(x.getValue().getCar().getColour())).
				map(x->x.getValue().getCar().getRegistrationNumber()).collect(Collectors.joining(", "));

		return output;
	}

}
