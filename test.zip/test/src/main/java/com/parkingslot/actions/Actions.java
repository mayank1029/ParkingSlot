package com.parkingslot.actions;

public interface Actions {

	public String process() throws NullPointerException;
}
