package com.parkingslot.actions;

import java.util.Map;
import java.util.stream.Collectors;

import com.parkingslot.main.ParkingSlotApplication;
import com.parkingslot.model.Ticket;

public class StatusOfParkingSlots implements Actions {

	private Map<Integer,Ticket> issueTicket;

	public StatusOfParkingSlots(String[] input) {
		this.issueTicket=ParkingSlotApplication.getIssueTicket();
	}

	@Override
	public String process() throws NullPointerException{
		String output="Slot No.     "+"Registration No.     "+"Colour\n";
		String status=issueTicket.entrySet().stream().
				map(x-> x.getKey()+"    "+x.getValue().getCar().getRegistrationNumber()+"    "+x.getValue().getCar().getColour()).collect(Collectors.joining("\n"));

		return output+status;
	}

}
